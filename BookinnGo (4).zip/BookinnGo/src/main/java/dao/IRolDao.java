
package dao;

import model.Rol;


public interface IRolDao extends IBaseDao<Rol>{
    
}
