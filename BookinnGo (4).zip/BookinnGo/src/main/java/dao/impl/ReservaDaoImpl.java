
package dao.impl;

import ConexionBase.Conexion;
import model.Cliente;
import model.Habitacion;
import model.Reserva;
import dao.IReservaDao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class ReservaDaoImpl implements IReservaDao {

private final Conexion conexion;

    public ReservaDaoImpl(Conexion conexion) {
        this.conexion = conexion;
    }

    @Override
    public void create(Reserva reserva) throws SQLException {
        String sql = "INSERT INTO reservas (id_cliente, id_trabajador, id_habitacion, " +
                     "fecha_reserva, fecha_entrada, fecha_salida, tipo_reserva, observacion, estado, total) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setLong(1, reserva.getCliente().getIdCliente());
            stmt.setLong(2, reserva.getTrabajador().getIdTrabajador());
            stmt.setLong(3, reserva.getHabitacion().getIdHabitacion());
            stmt.setDate(4, Date.valueOf(reserva.getFechaReserva()));
            stmt.setDate(5, Date.valueOf(reserva.getFechaEntrada()));
            stmt.setDate(6, Date.valueOf(reserva.getFechaSalida()));
            stmt.setString(7, reserva.getTipoReserva());
            stmt.setString(8, reserva.getObservacion());
            stmt.setString(9, reserva.getEstado());
            stmt.setDouble(10, reserva.getTotal());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    reserva.setIdReserva(rs.getLong(1));
                }
            }
        }
    }

    @Override
    public Reserva read(Long id) throws SQLException {
        String sql = "SELECT r.*, " +
                     "c.id_cliente, c.primer_nombre AS c_primer_nombre, c.primer_apellido AS c_primer_apellido, " +
                     "h.id_habitacion, h.numero, h.tipo_habitacion, h.precio " +
                     "FROM reservas r " +
                     "JOIN clientes c ON r.id_cliente = c.id_cliente " +
                     "JOIN habitaciones h ON r.id_habitacion = h.id_habitacion " +
                     "WHERE r.id_reserva = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToReserva(rs);
                }
            }
        }

        return null;
    }

    @Override
    public void update(Reserva reserva) throws SQLException {
        String sql = "UPDATE reservas SET id_cliente = ?, id_trabajador = ?, id_habitacion = ?, " +
                     "fecha_reserva = ?, fecha_entrada = ?, fecha_salida = ?, tipo_reserva = ?, " +
                     "observacion = ?, estado = ?, total = ? WHERE id_reserva = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, reserva.getCliente().getIdCliente());
            stmt.setLong(2, reserva.getTrabajador().getIdTrabajador());
            stmt.setLong(3, reserva.getHabitacion().getIdHabitacion());
            stmt.setDate(4, Date.valueOf(reserva.getFechaReserva()));
            stmt.setDate(5, Date.valueOf(reserva.getFechaEntrada()));
            stmt.setDate(6, Date.valueOf(reserva.getFechaSalida()));
            stmt.setString(7, reserva.getTipoReserva());
            stmt.setString(8, reserva.getObservacion());
            stmt.setString(9, reserva.getEstado());
            stmt.setDouble(10, reserva.getTotal());
            stmt.setLong(11, reserva.getIdReserva());

            stmt.executeUpdate();
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        String sql = "DELETE FROM reservas WHERE id_reserva = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Reserva> findAll() throws SQLException {
        List<Reserva> reservas = new ArrayList<>();

        String sql = "SELECT r.*, " +
                     "c.id_cliente, c.primer_nombre AS c_primer_nombre, c.primer_apellido AS c_primer_apellido, " +
                     "h.id_habitacion, h.numero, h.tipo_habitacion, h.precio " +
                     "FROM reservas r " +
                     "JOIN clientes c ON r.id_cliente = c.id_cliente " +
                     "JOIN habitaciones h ON r.id_habitacion = h.id_habitacion";

        try (Connection conn = conexion.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                reservas.add(mapResultSetToReserva(rs));
            }
        }

        return reservas;
    }

    @Override
    public List<Reserva> findByCliente(Long idCliente) throws SQLException {
        List<Reserva> reservas = new ArrayList<>();

        String sql = "SELECT r.*, " +
                     "c.id_cliente, c.primer_nombre AS c_primer_nombre, c.primer_apellido AS c_primer_apellido, " +
                     "h.id_habitacion, h.numero, h.tipo_habitacion, h.precio " +
                     "FROM reservas r " +
                     "JOIN clientes c ON r.id_cliente = c.id_cliente " +
                     "JOIN habitaciones h ON r.id_habitacion = h.id_habitacion " +
                     "WHERE r.id_cliente = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, idCliente);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservas.add(mapResultSetToReserva(rs));
                }
            }
        }

        return reservas;
    }

    @Override
    public List<Reserva> findByEstado(String estado) throws SQLException {
        List<Reserva> reservas = new ArrayList<>();

        String sql = "SELECT r.*, " +
                     "c.id_cliente, c.primer_nombre AS c_primer_nombre, c.primer_apellido AS c_primer_apellido, " +
                     "h.id_habitacion, h.numero, h.tipo_habitacion, h.precio " +
                     "FROM reservas r " +
                     "JOIN clientes c ON r.id_cliente = c.id_cliente " +
                     "JOIN habitaciones h ON r.id_habitacion = h.id_habitacion " +
                     "WHERE r.estado = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, estado);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservas.add(mapResultSetToReserva(rs));
                }
            }
        }

        return reservas;
    }

    @Override
    public List<Reserva> findByFecha(LocalDate fecha) throws SQLException {
        List<Reserva> reservas = new ArrayList<>();

        String sql = "SELECT r.*, " +
                     "c.id_cliente, c.primer_nombre AS c_primer_nombre, c.primer_apellido AS c_primer_apellido, " +
                     "h.id_habitacion, h.numero, h.tipo_habitacion, h.precio " +
                     "FROM reservas r " +
                     "JOIN clientes c ON r.id_cliente = c.id_cliente " +
                     "JOIN habitaciones h ON r.id_habitacion = h.id_habitacion " +
                     "WHERE r.fecha_reserva = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, Date.valueOf(fecha));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservas.add(mapResultSetToReserva(rs));
                }
            }
        }

        return reservas;
    }

    // Mapea los resultados SQL a un objeto Reserva completo
    private Reserva mapResultSetToReserva(ResultSet rs) throws SQLException {
        Reserva reserva = new Reserva();
        reserva.setIdReserva(rs.getLong("id_reserva"));
        reserva.setFechaReserva(rs.getDate("fecha_reserva").toLocalDate());
        reserva.setFechaEntrada(rs.getDate("fecha_entrada").toLocalDate());
        reserva.setFechaSalida(rs.getDate("fecha_salida").toLocalDate());
        reserva.setTipoReserva(rs.getString("tipo_reserva"));
        reserva.setObservacion(rs.getString("observacion"));
        reserva.setEstado(rs.getString("estado"));
        reserva.setTotal(rs.getDouble("total"));

        Cliente cliente = new Cliente();
        cliente.setIdCliente(rs.getLong("id_cliente"));
        cliente.setPrimerNombre(rs.getString("c_primer_nombre"));
        cliente.setPrimerApellido(rs.getString("c_primer_apellido"));
        reserva.setCliente(cliente);

        Habitacion habitacion = new Habitacion();
        habitacion.setIdHabitacion(rs.getLong("id_habitacion"));
        habitacion.setNumero(rs.getString("numero"));
        habitacion.setTipoHabitacion(rs.getString("tipo_habitacion"));
        habitacion.setPrecio(rs.getDouble("precio"));
        reserva.setHabitacion(habitacion);

        // OJO: Trabajador no está en el SELECT.
        // Si necesitas setearlo, debes hacer el JOIN y mapearlo aquí.

        return reserva;
    }
}