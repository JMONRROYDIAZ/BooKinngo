package ConexionBase;

import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        Database dbConfig = new Database(
                "localhost", "1521", "XE", "Hotel", "HotelPwd"
        );

        IConexion conexion = new Conexion(dbConfig);

        try {
            conexion.connect();
            System.out.println("Conexión exitosa a la base de datos Oracle.");
        } catch (Exception e) {
            System.out.println("Error al conectar con la base de datos: " + e.getMessage());
        } finally {
            try {
                conexion.disconnect();
            } catch (Exception e) {
                System.out.println("No se pudo cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
