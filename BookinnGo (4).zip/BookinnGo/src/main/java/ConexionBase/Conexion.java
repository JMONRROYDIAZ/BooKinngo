
package ConexionBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion implements IConexion {

    private final Database config;
    private Connection connection;

    public Conexion(Database config) {
        this.config = config;
    }

    @Override
    public Connection connect() throws SQLException {
        try {
            // Cargar el driver JDBC de Oracle
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Intentar establecer la conexión
            connection = DriverManager.getConnection(
                    config.getJdbcUrl(),
                    config.getUser(),
                    config.getPassword()
            );

            System.out.println("Conexión establecida con Oracle (" + config.getUser() + ")");
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se encontró el driver JDBC de Oracle", e);
        } catch (SQLException e) {
            throw new SQLException("Error al conectar con la base de datos: " + e.getMessage(), e);
        }

        return connection;
    }

    @Override
    public void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
            System.out.println("Conexión cerrada correctamente");
        }
    }


}


