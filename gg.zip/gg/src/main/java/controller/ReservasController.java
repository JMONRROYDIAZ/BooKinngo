package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Reserva;
import service.IReservaService;
import service.impl.ReservaServiceImpl;
import dao.impl.ReservaDaoImpl;
import ConexionBase.Conexion;
import ConexionBase.Database;

import java.sql.SQLException;
import java.util.List;

public class ReservasController {

    @FXML
    private TableView<Reserva> tableReservas;
    
    @FXML
    private TableColumn<Reserva, Long> colIdReserva;
    
    @FXML
    private TableColumn<Reserva, String> colCliente;
    
    @FXML
    private TableColumn<Reserva, String> colHabitacion;
    
    @FXML
    private TableColumn<Reserva, String> colFechaEntrada;
    
    @FXML
    private TableColumn<Reserva, String> colFechaSalida;
    
    @FXML
    private TableColumn<Reserva, String> colEstado;
    
    @FXML
    private TextField txtBuscar;

    private IReservaService reservaService;
    private ObservableList<Reserva> reservasList;

    @FXML
    public void initialize() {
        // Inicializar servicio
        Database db = new Database("localhost", 1521, "orcl", "system", "123");
        Conexion conexion = new Conexion(db);
        reservaService = new ReservaServiceImpl(new ReservaDaoImpl(conexion));
        
        reservasList = FXCollections.observableArrayList();
        
        // Configurar columnas (estas se configurarían con PropertyValueFactory en implementación completa)
        
        // Cargar datos
        cargarReservas();
    }

    private void cargarReservas() {
        try {
            List<Reserva> reservas = reservaService.listarTodos();
            reservasList.clear();
            reservasList.addAll(reservas);
            tableReservas.setItems(reservasList);
        } catch (SQLException e) {
            mostrarError("Error al cargar reservas", e.getMessage());
        }
    }

    @FXML
    private void handleNuevo() {
        // Lógica para nueva reserva
    }

    @FXML
    private void handleEditar() {
        // Lógica para editar reserva seleccionada
    }

    @FXML
    private void handleEliminar() {
        // Lógica para eliminar reserva seleccionada
    }

    @FXML
    private void handleBuscar() {
        // Lógica para buscar reservas
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
