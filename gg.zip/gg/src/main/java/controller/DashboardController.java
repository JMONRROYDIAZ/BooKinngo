package controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML
    private Label lblFechaActual;

    @FXML
    private Label lblUsuarioTurno;

    @FXML
    private Label lblCheckInsHoy;

    @FXML
    private Label lblCheckOutsHoy;

    @FXML
    private Label lblHabitacionesDisponibles;

    @FXML
    private Label lblHabitacionesOcupadas;

    @FXML
    private Label lblTotalHabitaciones;

    @FXML
    private Label lblPorcentajeOcupacion;

    @FXML
    private Label lblBadgeCheckIns;

    @FXML
    private VBox vboxCheckInsPendientes;

    // Datos de ejemplo (puedes conectarlos con tu DAO)
    private int checkInsHoy = 0;
    private int checkOutsHoy = 0;
    private int habitacionesDisponibles = 3;
    private int habitacionesOcupadas = 2;
    private int totalHabitaciones = 6;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        actualizarFechaHora();
        actualizarEstadisticas();
    }

    private void actualizarFechaHora() {
        LocalDateTime ahora = LocalDateTime.now();

        // Formato: "Domingo, 9 De Noviembre De 2025"
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern(
                "EEEE, d 'De' MMMM 'De' yyyy",
                new Locale("es", "ES")
        );
        String fechaFormateada = ahora.format(formatoFecha);
        // Capitalizar primera letra
        fechaFormateada = fechaFormateada.substring(0, 1).toUpperCase() + fechaFormateada.substring(1);
        lblFechaActual.setText(fechaFormateada);

        // Formato: "Carlos Mendoza - Turno (14:55)"
        DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm");
        String horaFormateada = ahora.format(formatoHora);
        lblUsuarioTurno.setText("Carlos Mendoza - Turno (" + horaFormateada + ")");
    }

    private void actualizarEstadisticas() {
        // Actualizar las etiquetas con los datos
        lblCheckInsHoy.setText(String.valueOf(checkInsHoy));
        lblCheckOutsHoy.setText(String.valueOf(checkOutsHoy));
        lblHabitacionesDisponibles.setText(String.valueOf(habitacionesDisponibles));
        lblHabitacionesOcupadas.setText(String.valueOf(habitacionesOcupadas));
        lblTotalHabitaciones.setText("De " + totalHabitaciones + " totales");
        lblBadgeCheckIns.setText(String.valueOf(checkInsHoy));

        // Calcular porcentaje de ocupación
        double porcentaje = (habitacionesOcupadas * 100.0) / totalHabitaciones;
        lblPorcentajeOcupacion.setText(String.format("Ocupación: %.0f%%", porcentaje));
    }

    // ===== MÉTODOS PÚBLICOS PARA ACTUALIZAR DATOS =====

    public void actualizarCheckIns(int cantidad) {
        this.checkInsHoy = cantidad;
        lblCheckInsHoy.setText(String.valueOf(cantidad));
        lblBadgeCheckIns.setText(String.valueOf(cantidad));
    }

    public void actualizarCheckOuts(int cantidad) {
        this.checkOutsHoy = cantidad;
        lblCheckOutsHoy.setText(String.valueOf(cantidad));
    }

    public void actualizarHabitaciones(int disponibles, int ocupadas, int total) {
        this.habitacionesDisponibles = disponibles;
        this.habitacionesOcupadas = ocupadas;
        this.totalHabitaciones = total;
        actualizarEstadisticas();
    }
}
