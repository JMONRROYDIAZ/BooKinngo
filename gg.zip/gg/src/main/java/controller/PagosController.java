package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Comprobante;
import service.IComprobanteService;
import service.impl.ComprobanteServiceImpl;
import dao.impl.ComprobanteDaoImpl;
import ConexionBase.Conexion;
import ConexionBase.Database;

import java.sql.SQLException;
import java.util.List;

public class PagosController {

    @FXML
    private TableView<Comprobante> tablePagos;
    
    @FXML
    private TextField txtBuscar;

    private IComprobanteService comprobanteService;
    private ObservableList<Comprobante> pagosList;

    @FXML
    public void initialize() {
        // Inicializar servicio
        Database db = new Database("localhost", 1521, "orcl", "system", "123");
        Conexion conexion = new Conexion(db);
        comprobanteService = new ComprobanteServiceImpl(new ComprobanteDaoImpl(conexion));
        
        pagosList = FXCollections.observableArrayList();
        
        // Cargar datos
        cargarPagos();
    }

    private void cargarPagos() {
        try {
            List<Comprobante> comprobantes = comprobanteService.listarTodos();
            pagosList.clear();
            pagosList.addAll(comprobantes);
            tablePagos.setItems(pagosList);
        } catch (SQLException e) {
            mostrarError("Error al cargar pagos", e.getMessage());
        }
    }

    @FXML
    private void handleNuevo() {
        // Lógica para nuevo pago
    }

    @FXML
    private void handleEditar() {
        // Lógica para editar pago seleccionado
    }

    @FXML
    private void handleEliminar() {
        // Lógica para eliminar pago seleccionado
    }

    @FXML
    private void handleBuscar() {
        // Lógica para buscar pagos
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
