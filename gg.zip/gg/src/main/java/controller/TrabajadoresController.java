package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Trabajador;
import service.ITrabajadorService;
import service.impl.TrabajadorServiceImpl;
import dao.impl.TrabajadorDaoImpl;
import ConexionBase.Conexion;
import ConexionBase.Database;

import java.sql.SQLException;
import java.util.List;

public class TrabajadoresController {

    @FXML
    private TableView<Trabajador> tableTrabajadores;
    
    @FXML
    private TextField txtBuscar;

    private ITrabajadorService trabajadorService;
    private ObservableList<Trabajador> trabajadoresList;

    @FXML
    public void initialize() {
        // Inicializar servicio
        Database db = new Database("localhost", 1521, "orcl", "system", "123");
        Conexion conexion = new Conexion(db);
        trabajadorService = new TrabajadorServiceImpl(new TrabajadorDaoImpl(conexion));
        
        trabajadoresList = FXCollections.observableArrayList();
        
        // Cargar datos
        cargarTrabajadores();
    }

    private void cargarTrabajadores() {
        try {
            List<Trabajador> trabajadores = trabajadorService.listarTodos();
            trabajadoresList.clear();
            trabajadoresList.addAll(trabajadores);
            tableTrabajadores.setItems(trabajadoresList);
        } catch (SQLException e) {
            mostrarError("Error al cargar trabajadores", e.getMessage());
        }
    }

    @FXML
    private void handleNuevo() {
        // Lógica para nuevo trabajador
    }

    @FXML
    private void handleEditar() {
        // Lógica para editar trabajador seleccionado
    }

    @FXML
    private void handleEliminar() {
        // Lógica para eliminar trabajador seleccionado
    }

    @FXML
    private void handleBuscar() {
        // Lógica para buscar trabajadores
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
