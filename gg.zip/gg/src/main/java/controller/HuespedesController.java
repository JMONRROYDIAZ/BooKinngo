package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Cliente;
import service.IClienteService;
import service.impl.ClienteServiceImpl;
import dao.impl.ClienteDaoImpl;
import ConexionBase.Conexion;
import ConexionBase.Database;

import java.sql.SQLException;
import java.util.List;

public class HuespedesController {

    @FXML
    private TableView<Cliente> tableHuespedes;
    
    @FXML
    private TextField txtBuscar;

    private IClienteService clienteService;
    private ObservableList<Cliente> huespedesList;

    @FXML
    public void initialize() {
        // Inicializar servicio
        Database db = new Database("localhost", 1521, "orcl", "system", "123");
        Conexion conexion = new Conexion(db);
        clienteService = new ClienteServiceImpl(new ClienteDaoImpl(conexion));
        
        huespedesList = FXCollections.observableArrayList();
        
        // Cargar datos
        cargarHuespedes();
    }

    private void cargarHuespedes() {
        try {
            List<Cliente> clientes = clienteService.listarTodos();
            huespedesList.clear();
            huespedesList.addAll(clientes);
            tableHuespedes.setItems(huespedesList);
        } catch (SQLException e) {
            mostrarError("Error al cargar huéspedes", e.getMessage());
        }
    }

    @FXML
    private void handleNuevo() {
        // Lógica para nuevo huésped
    }

    @FXML
    private void handleEditar() {
        // Lógica para editar huésped seleccionado
    }

    @FXML
    private void handleEliminar() {
        // Lógica para eliminar huésped seleccionado
    }

    @FXML
    private void handleBuscar() {
        // Lógica para buscar huéspedes
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
