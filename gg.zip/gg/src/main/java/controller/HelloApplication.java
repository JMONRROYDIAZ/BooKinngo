package controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Cargar la pantalla de Login primero
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/hotel/view/Login.fxml")
        );
        Scene scene = new Scene(loader.load());
        primaryStage.setTitle("BookinnGo - Iniciar Sesión");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false); // Login no redimensionable
        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
