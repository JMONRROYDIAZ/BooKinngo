package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Rol;
import service.IRolService;
import service.impl.RolServiceImpl;
import dao.impl.RolDaoImpl;
import ConexionBase.Conexion;
import ConexionBase.Database;

import java.sql.SQLException;
import java.util.List;

public class RolesController {

    @FXML
    private TableView<Rol> tableRoles;
    
    @FXML
    private TextField txtBuscar;

    private IRolService rolService;
    private ObservableList<Rol> rolesList;

    @FXML
    public void initialize() {
        // Inicializar servicio
        Database db = new Database("localhost", 1521, "orcl", "system", "123");
        Conexion conexion = new Conexion(db);
        rolService = new RolServiceImpl(new RolDaoImpl(conexion));
        
        rolesList = FXCollections.observableArrayList();
        
        // Cargar datos
        cargarRoles();
    }

    private void cargarRoles() {
        try {
            List<Rol> roles = rolService.listarTodos();
            rolesList.clear();
            rolesList.addAll(roles);
            tableRoles.setItems(rolesList);
        } catch (SQLException e) {
            mostrarError("Error al cargar roles", e.getMessage());
        }
    }

    @FXML
    private void handleNuevo() {
        // Lógica para nuevo rol
    }

    @FXML
    private void handleEditar() {
        // Lógica para editar rol seleccionado
    }

    @FXML
    private void handleEliminar() {
        // Lógica para eliminar rol seleccionado
    }

    @FXML
    private void handleBuscar() {
        // Lógica para buscar roles
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
