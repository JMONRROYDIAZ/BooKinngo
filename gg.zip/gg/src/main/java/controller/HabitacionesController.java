package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Habitacion;
import service.IHabitacionService;
import service.impl.HabitacionServiceImpl;
import dao.impl.HabitacionDaoImpl;
import ConexionBase.Conexion;
import ConexionBase.Database;

import java.sql.SQLException;
import java.util.List;

public class HabitacionesController {

    @FXML
    private TableView<Habitacion> tableHabitaciones;
    
    @FXML
    private TextField txtBuscar;

    private IHabitacionService habitacionService;
    private ObservableList<Habitacion> habitacionesList;

    @FXML
    public void initialize() {
        // Inicializar servicio
        Database db = new Database("localhost", 1521, "orcl", "system", "123");
        Conexion conexion = new Conexion(db);
        habitacionService = new HabitacionServiceImpl(new HabitacionDaoImpl(conexion));
        
        habitacionesList = FXCollections.observableArrayList();
        
        // Cargar datos
        cargarHabitaciones();
    }

    private void cargarHabitaciones() {
        try {
            List<Habitacion> habitaciones = habitacionService.listarTodos();
            habitacionesList.clear();
            habitacionesList.addAll(habitaciones);
            tableHabitaciones.setItems(habitacionesList);
        } catch (SQLException e) {
            mostrarError("Error al cargar habitaciones", e.getMessage());
        }
    }

    @FXML
    private void handleNuevo() {
        // Lógica para nueva habitación
    }

    @FXML
    private void handleEditar() {
        // Lógica para editar habitación seleccionada
    }

    @FXML
    private void handleEliminar() {
        // Lógica para eliminar habitación seleccionada
    }

    @FXML
    private void handleBuscar() {
        // Lógica para buscar habitaciones
    }

    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
