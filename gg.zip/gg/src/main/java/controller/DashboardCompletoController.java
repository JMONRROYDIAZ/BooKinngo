package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import utils.AnimationUtils;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

public class DashboardCompletoController implements Initializable {

    // ===== SIDEBAR ELEMENTS =====
    @FXML private Button btnDashboard;
    @FXML private Button btnReservas;
    @FXML private Button btnHabitaciones;
    @FXML private Button btnHuespedes;
    @FXML private Button btnPagos;
    @FXML private Button btnTrabajadores;
    @FXML private Button btnRoles;
    
    @FXML private Label lblUsuarioActual;
    @FXML private Label lblRolActual;

    // ===== DASHBOARD ELEMENTS =====
    @FXML private StackPane contentArea;
    @FXML private Label lblFechaActual;
    @FXML private Label lblUsuarioTurno;
    @FXML private Label lblCheckInsHoy;
    @FXML private Label lblCheckOutsHoy;
    @FXML private Label lblHabitacionesDisponibles;
    @FXML private Label lblHabitacionesOcupadas;
    @FXML private Label lblTotalHabitaciones;
    @FXML private Label lblPorcentajeOcupacion;
    @FXML private Label lblBadgeCheckIns;
    @FXML private VBox vboxCheckInsPendientes;

    // Datos de ejemplo (puedes conectarlos con tu DAO)
    private int checkInsHoy = 0;
    private int checkOutsHoy = 0;
    private int habitacionesDisponibles = 3;
    private int habitacionesOcupadas = 2;
    private int totalHabitaciones = 6;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Configurar usuario
        lblUsuarioActual.setText("Carlos Mendoza");
        lblRolActual.setText("ADMINISTRADOR");
        
        // Actualizar fecha y estadísticas
        actualizarFechaHora();
        actualizarEstadisticas();
        
        // Aplicar animaciones de entrada
        aplicarAnimacionesIniciales();
        
        // Aplicar efectos hover a botones del sidebar
        aplicarEfectosHover();
    }

    // ===== MÉTODOS DE NAVEGACIÓN =====

    @FXML
    private void handleDashboard() {
        System.out.println("Navegando a Dashboard");
        // El dashboard ya está visible, solo actualiza el estilo del botón
        activarBoton(btnDashboard);
        // Aquí podrías recargar los datos del dashboard si es necesario
        actualizarEstadisticas();
    }

    @FXML
    private void handleReservas() {
        System.out.println("Navegando a Reservas");
        activarBoton(btnReservas);
        cargarVista("ReservasView");
    }

    @FXML
    private void handleHabitaciones() {
        System.out.println("Navegando a Habitaciones");
        activarBoton(btnHabitaciones);
        cargarVista("HabitacionesView");
    }

    @FXML
    private void handleHuespedes() {
        System.out.println("Navegando a Huéspedes");
        activarBoton(btnHuespedes);
        cargarVista("HuespedesView");
    }

    @FXML
    private void handlePagos() {
        System.out.println("Navegando a Pagos");
        activarBoton(btnPagos);
        cargarVista("PagosView");
    }

    @FXML
    private void handleTrabajadores() {
        System.out.println("Navegando a Trabajadores");
        activarBoton(btnTrabajadores);
        cargarVista("TrabajadoresView");
    }

    @FXML
    private void handleRoles() {
        System.out.println("Navegando a Roles");
        activarBoton(btnRoles);
        cargarVista("RolesView");
    }

    @FXML
    private void handleCerrarSesion() {
        System.out.println("Cerrando sesión...");
        // Aquí implementarías la lógica para cerrar sesión
    }

    // ===== MÉTODOS AUXILIARES =====

    private void activarBoton(Button botonActivo) {
        // Resetear todos los botones a estilo inactivo
        String estiloInactivo = "-fx-background-color: transparent; -fx-text-fill: white; -fx-background-radius: 8; -fx-cursor: hand;";
        String estiloActivo = "-fx-background-color: white; -fx-text-fill: #1e3a8a; -fx-background-radius: 8; -fx-cursor: hand; -fx-font-size: 13px; -fx-font-weight: 500;";
        
        btnDashboard.setStyle(estiloInactivo);
        btnReservas.setStyle(estiloInactivo);
        btnHabitaciones.setStyle(estiloInactivo);
        btnHuespedes.setStyle(estiloInactivo);
        btnPagos.setStyle(estiloInactivo);
        btnTrabajadores.setStyle(estiloInactivo);
        btnRoles.setStyle(estiloInactivo);
        
        // Activar el botón seleccionado
        botonActivo.setStyle(estiloActivo);
    }

    private void cargarVista(String nombreVista) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/hotel/view/" + nombreVista + ".fxml")
            );
            Node vista = loader.load();
            contentArea.getChildren().clear();
            contentArea.getChildren().add(vista);
            System.out.println("Vista cargada: " + nombreVista);
        } catch (IOException e) {
            System.err.println("Error al cargar vista: " + nombreVista);
            e.printStackTrace();
        }
    }

    private void actualizarFechaHora() {
        LocalDateTime ahora = LocalDateTime.now();

        // Formato: "Domingo, 9 De Noviembre De 2025"
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern(
                "EEEE, d 'De' MMMM 'De' yyyy",
                new Locale("es", "ES")
        );
        String fechaFormateada = ahora.format(formatoFecha);
        fechaFormateada = fechaFormateada.substring(0, 1).toUpperCase() + fechaFormateada.substring(1);
        lblFechaActual.setText(fechaFormateada);

        // Formato: "Carlos Mendoza - Turno (14:55)"
        DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm");
        String horaFormateada = ahora.format(formatoHora);
        lblUsuarioTurno.setText(lblUsuarioActual.getText() + " - Turno (" + horaFormateada + ")");
    }

    private void actualizarEstadisticas() {
        // Actualizar las etiquetas con los datos
        lblCheckInsHoy.setText(String.valueOf(checkInsHoy));
        lblCheckOutsHoy.setText(String.valueOf(checkOutsHoy));
        lblHabitacionesDisponibles.setText(String.valueOf(habitacionesDisponibles));
        lblHabitacionesOcupadas.setText(String.valueOf(habitacionesOcupadas));
        lblTotalHabitaciones.setText("De " + totalHabitaciones + " totales");
        lblBadgeCheckIns.setText(String.valueOf(checkInsHoy));

        // Calcular porcentaje de ocupación
        double porcentaje = (habitacionesOcupadas * 100.0) / totalHabitaciones;
        lblPorcentajeOcupacion.setText(String.format("Ocupación: %.0f%%", porcentaje));
    }

    // ===== MÉTODOS PÚBLICOS PARA ACTUALIZAR DATOS =====

    public void actualizarCheckIns(int cantidad) {
        this.checkInsHoy = cantidad;
        lblCheckInsHoy.setText(String.valueOf(cantidad));
        lblBadgeCheckIns.setText(String.valueOf(cantidad));
    }

    public void actualizarCheckOuts(int cantidad) {
        this.checkOutsHoy = cantidad;
        lblCheckOutsHoy.setText(String.valueOf(cantidad));
    }

    public void actualizarHabitaciones(int disponibles, int ocupadas, int total) {
        this.habitacionesDisponibles = disponibles;
        this.habitacionesOcupadas = ocupadas;
        this.totalHabitaciones = total;
        actualizarEstadisticas();
    }

    public void setUsuario(String nombre, String rol) {
        lblUsuarioActual.setText(nombre);
        lblRolActual.setText(rol.toUpperCase());
        actualizarFechaHora();
    }
    
    // ===== MÉTODOS DE ANIMACIÓN =====
    
    /**
     * Aplica animaciones de entrada a los elementos del dashboard
     */
    private void aplicarAnimacionesIniciales() {
        // Animar tarjetas de estadísticas con delay progresivo
        javafx.application.Platform.runLater(() -> {
            // Encontrar las tarjetas (asumiendo que están en un GridPane)
            try {
                // Buscar el contentArea y aplicar fade in
                if (contentArea != null) {
                    AnimationUtils.fadeIn(contentArea, 400);
                }
            } catch (Exception e) {
                System.out.println("No se pudieron animar los elementos: " + e.getMessage());
            }
        });
    }
    
    /**
     * Aplica efectos hover a los botones del sidebar
     */
    private void aplicarEfectosHover() {
        // Aplicar efecto hover a cada botón del sidebar
        if (btnDashboard != null) applyButtonHover(btnDashboard);
        if (btnReservas != null) applyButtonHover(btnReservas);
        if (btnHabitaciones != null) applyButtonHover(btnHabitaciones);
        if (btnHuespedes != null) applyButtonHover(btnHuespedes);
        if (btnPagos != null) applyButtonHover(btnPagos);
        if (btnTrabajadores != null) applyButtonHover(btnTrabajadores);
        if (btnRoles != null) applyButtonHover(btnRoles);
    }
    
    /**
     * Aplica efecto hover individual a un botón
     */
    private void applyButtonHover(Button button) {
        button.setOnMouseEntered(e -> {
            javafx.animation.TranslateTransition tt = new javafx.animation.TranslateTransition(
                javafx.util.Duration.millis(200), button
            );
            tt.setToX(5);
            tt.play();
        });
        
        button.setOnMouseExited(e -> {
            javafx.animation.TranslateTransition tt = new javafx.animation.TranslateTransition(
                javafx.util.Duration.millis(200), button
            );
            tt.setToX(0);
            tt.play();
        });
    }
    
    /**
     * Anima el cambio de vista con transición suave
     */
    private void animateViewChange(Node newView) {
        if (newView != null) {
            AnimationUtils.slideInRight(newView, 400);
        }
    }
}

