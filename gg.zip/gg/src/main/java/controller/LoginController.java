package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import utils.Animations;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtContrasena;
    @FXML private CheckBox chkRecordarme;
    @FXML private Button btnLogin;
    @FXML private VBox vboxMensaje;
    @FXML private Label lblMensaje;
    @FXML private VBox vboxFormulario;
    @FXML private HBox hboxLogo;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Configuración inicial
        ocultarMensaje();
        
        // Focus en el campo de usuario al iniciar
        txtUsuario.requestFocus();
        
        // Cargar credenciales guardadas si existen
        cargarCredencialesGuardadas();
        
        // ===== ANIMACIONES DE ENTRADA =====
        aplicarAnimacionesIniciales();
        
        // Agregar efectos hover a los botones
        Animations.addHoverEffect(btnLogin);
        Animations.addClickEffect(btnLogin);
    }
    
    private void aplicarAnimacionesIniciales() {
        // Animar logo con fadeIn
        if (hboxLogo != null) {
            Animations.fadeIn(hboxLogo, 800);
        }
        
        // Animar formulario con slideInUp
        if (vboxFormulario != null) {
            Animations.slideInUp(vboxFormulario, 1000);
        }
        
        // Animar campos en secuencia
        Animations.animateSequence(150, txtUsuario, txtContrasena, chkRecordarme, btnLogin);
    }

    @FXML
    private void handleLogin() {
        // Obtener datos del formulario
        String usuario = txtUsuario.getText().trim();
        String contrasena = txtContrasena.getText();

        // Validar campos vacíos
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            mostrarMensajeError("Por favor complete todos los campos");
            Animations.shake(vboxMensaje);
            return;
        }

        // Deshabilitar botón mientras se procesa
        btnLogin.setDisable(true);
        btnLogin.setText("Iniciando sesión...");

        // Aquí va tu lógica de autenticación
        if (autenticarUsuario(usuario, contrasena)) {
            // Login exitoso
            mostrarMensajeExito("¡Bienvenido!");
            Animations.pulse(vboxMensaje, 2);
            
            guardarCredenciales(usuario);
            
            // Pequeño delay antes de abrir el sistema
            javafx.application.Platform.runLater(() -> {
                try {
                    Thread.sleep(800);
                    abrirSistemaPrincipal();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
        } else {
            // Login fallido
            mostrarMensajeError("Usuario o contraseña incorrectos");
            Animations.shake(vboxMensaje);
            btnLogin.setDisable(false);
            btnLogin.setText("Iniciar Sesión");
            txtContrasena.clear();
            txtContrasena.requestFocus();
        }
    }

    private boolean autenticarUsuario(String usuario, String contrasena) {
        // OPCIÓN 1: Autenticación simple (para pruebas)
        if (usuario.equals("admin") && contrasena.equals("admin123")) {
            return true;
        }
        if (usuario.equals("recepcion") && contrasena.equals("recep123")) {
            return true;
        }

        return false;
    }

    private void abrirSistemaPrincipal() {
        try {
            // Cargar la ventana principal (DashboardCompleto)
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/hotel/view/DashboardCompleto.fxml")
            );
            Parent root = loader.load();

            // Crear nueva ventana
            Stage stage = new Stage();
            stage.setTitle("BookinnGo - Sistema de Recepción");
            stage.setScene(new Scene(root));
            stage.setMaximized(true);
            stage.show();

            // Cerrar ventana de login con animación
            Stage loginStage = (Stage) btnLogin.getScene().getWindow();
            Animations.fadeOut(btnLogin.getScene().getRoot());
            javafx.application.Platform.runLater(() -> {
                try {
                    Thread.sleep(300);
                    loginStage.close();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

        } catch (IOException e) {
            mostrarMensajeError("Error al cargar el sistema principal");
            e.printStackTrace();
            btnLogin.setDisable(false);
            btnLogin.setText("Iniciar Sesión");
        }
    }

    @FXML
    private void handleOlvideContrasena() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Recuperar Contraseña");
        alert.setHeaderText("Contacta al Administrador");
        alert.setContentText("Para recuperar tu contraseña, por favor contacta al administrador del sistema.");
        alert.showAndWait();
    }

    @FXML
    private void handleContactarAdmin() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Contactar Administrador");
        alert.setHeaderText("Información de Contacto");
        alert.setContentText("Administrador: Carlos Mendoza\nEmail: admin@hotelluxe.com\nTeléfono: +57 300 123 4567");
        alert.showAndWait();
    }

    private void mostrarMensajeError(String mensaje) {
        lblMensaje.setText(mensaje);
        vboxMensaje.setVisible(true);
        vboxMensaje.setManaged(true);
        vboxMensaje.setStyle(
            "-fx-background-color: #fee2e2; " +
            "-fx-padding: 12 16; " +
            "-fx-background-radius: 10; " +
            "-fx-border-color: #fca5a5; " +
            "-fx-border-radius: 10;"
        );
        Animations.slideInUp(vboxMensaje, 400);
    }

    private void mostrarMensajeExito(String mensaje) {
        lblMensaje.setText(mensaje);
        vboxMensaje.setVisible(true);
        vboxMensaje.setManaged(true);
        vboxMensaje.setStyle(
            "-fx-background-color: #d1fae5; " +
            "-fx-padding: 12 16; " +
            "-fx-background-radius: 10; " +
            "-fx-border-color: #6ee7b7; " +
            "-fx-border-radius: 10;"
        );
        Animations.slideInUp(vboxMensaje, 400);
    }

    private void ocultarMensaje() {
        vboxMensaje.setVisible(false);
        vboxMensaje.setManaged(false);
    }

    private void guardarCredenciales(String usuario) {
        if (chkRecordarme.isSelected()) {
            System.out.println("Recordando usuario: " + usuario);
        }
    }

    private void cargarCredencialesGuardadas() {
        // Implementar carga de credenciales
    }
}

