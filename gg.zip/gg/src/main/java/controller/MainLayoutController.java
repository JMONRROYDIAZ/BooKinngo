package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainLayoutController implements Initializable {

    @FXML
    private StackPane contentArea;

    @FXML
    private Label lblUsuarioActual;

    @FXML
    private Label lblRolActual;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Configurar usuario actual
        lblUsuarioActual.setText("Carlos Mendoza");
        lblRolActual.setText("ADMINISTRADOR");
        
        // Cargar Dashboard por defecto
        handleDashboard();
    }

    // ===== MÉTODOS DE NAVEGACIÓN =====

    @FXML
    private void handleDashboard() {
        cargarVista("DashboardView");
    }

    @FXML
    private void handleReservas() {
        cargarVista("ReservasView");
    }

    @FXML
    private void handleHabitaciones() {
        cargarVista("HabitacionesView");
    }

    @FXML
    private void handleHuespedes() {
        cargarVista("HuespedesView");
    }

    @FXML
    private void handlePagos() {
        cargarVista("PagosView");
    }

    @FXML
    private void handleTrabajadores() {
        cargarVista("TrabajadoresView");
    }

    @FXML
    private void handleRoles() {
        cargarVista("RolesView");
    }

    @FXML
    private void handleCerrarSesion() {
        System.out.println("Cerrando sesión...");
        // Aquí implementarías la lógica para cerrar sesión
        // Por ejemplo: volver a la pantalla de login
    }

    // Método auxiliar para cargar vistas
    private void cargarVista(String nombreVista) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/hotel/view/" + nombreVista + ".fxml")
            );
            Node vista = loader.load();
            contentArea.getChildren().clear();
            contentArea.getChildren().add(vista);
            System.out.println("Vista cargada: " + nombreVista);
        } catch (IOException e) {
            System.err.println("Error al cargar vista: " + nombreVista);
            e.printStackTrace();
        }
    }

    // ===== MÉTODOS PÚBLICOS PARA ACTUALIZAR DATOS =====

    public void actualizarCheckIns(int cantidad) {
        this.checkInsHoy = cantidad;
        lblCheckInsHoy.setText(String.valueOf(cantidad));
    }

    public void actualizarCheckOuts(int cantidad) {
        this.checkOutsHoy = cantidad;
        lblCheckOutsHoy.setText(String.valueOf(cantidad));
    }

    public void actualizarHabitaciones(int disponibles, int ocupadas, int total) {
        this.habitacionesDisponibles = disponibles;
        this.habitacionesOcupadas = ocupadas;
        this.totalHabitaciones = total;
        actualizarEstadisticas();
    }

    public void setUsuario(String nombre, String rol) {
        lblUsuarioActual.setText(nombre);
        lblRolActual.setText(rol.toUpperCase());
        actualizarFechaHora();
    }
}