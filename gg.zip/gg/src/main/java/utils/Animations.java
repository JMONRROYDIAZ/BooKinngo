package utils;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.util.Duration;

/**
 * Utilidad para animaciones profesionales en JavaFX
 * Animaciones suaves y modernas para BookinnGo
 */
public class Animations {

    // ========== FADE IN ==========
    public static void fadeIn(Node node) {
        fadeIn(node, 500);
    }

    public static void fadeIn(Node node, double durationMillis) {
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();
    }

    // ========== FADE OUT ==========
    public static void fadeOut(Node node) {
        fadeOut(node, 500);
    }

    public static void fadeOut(Node node, double durationMillis) {
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        fade.play();
    }

    // ========== SLIDE IN UP ==========
    public static void slideInUp(Node node) {
        slideInUp(node, 600);
    }

    public static void slideInUp(Node node, double durationMillis) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(durationMillis), node);
        translate.setFromY(30);
        translate.setToY(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(translate, fade);
        parallel.play();
    }

    // ========== SLIDE IN LEFT ==========
    public static void slideInLeft(Node node) {
        slideInLeft(node, 600);
    }

    public static void slideInLeft(Node node, double durationMillis) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(durationMillis), node);
        translate.setFromX(-30);
        translate.setToX(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(translate, fade);
        parallel.play();
    }

    // ========== SLIDE IN RIGHT ==========
    public static void slideInRight(Node node) {
        slideInRight(node, 600);
    }

    public static void slideInRight(Node node, double durationMillis) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(durationMillis), node);
        translate.setFromX(30);
        translate.setToX(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(translate, fade);
        parallel.play();
    }

    // ========== SCALE UP ==========
    public static void scaleUp(Node node) {
        scaleUp(node, 400);
    }

    public static void scaleUp(Node node, double durationMillis) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(durationMillis), node);
        scale.setFromX(0.8);
        scale.setFromY(0.8);
        scale.setToX(1.0);
        scale.setToY(1.0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(scale, fade);
        parallel.play();
    }

    // ========== PULSE ==========
    public static void pulse(Node node) {
        pulse(node, 1);
    }

    public static void pulse(Node node, int cycles) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(400), node);
        scale.setFromX(1.0);
        scale.setFromY(1.0);
        scale.setToX(1.05);
        scale.setToY(1.05);
        scale.setCycleCount(cycles * 2);
        scale.setAutoReverse(true);
        scale.play();
    }

    // ========== SHAKE ==========
    public static void shake(Node node) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(50), node);
        translate.setFromX(0);
        translate.setByX(10);
        translate.setCycleCount(6);
        translate.setAutoReverse(true);
        translate.play();
    }

    // ========== BOUNCE ==========
    public static void bounce(Node node) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(400), node);
        translate.setFromY(0);
        translate.setToY(-20);
        translate.setCycleCount(2);
        translate.setAutoReverse(true);
        translate.setInterpolator(Interpolator.EASE_OUT);
        translate.play();
    }

    // ========== ROTATE ==========
    public static void rotate(Node node) {
        rotate(node, 360, 1000);
    }

    public static void rotate(Node node, double angle, double durationMillis) {
        RotateTransition rotate = new RotateTransition(Duration.millis(durationMillis), node);
        rotate.setByAngle(angle);
        rotate.play();
    }

    // ========== SLIDE OUT DOWN ==========
    public static void slideOutDown(Node node) {
        slideOutDown(node, 500);
    }

    public static void slideOutDown(Node node, double durationMillis) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(durationMillis), node);
        translate.setFromY(0);
        translate.setToY(30);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMillis), node);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        
        ParallelTransition parallel = new ParallelTransition(translate, fade);
        parallel.play();
    }

    // ========== ANIMACIÓN EN SECUENCIA ==========
    public static void animateSequence(Node... nodes) {
        animateSequence(100, nodes);
    }

    public static void animateSequence(double delayMillis, Node... nodes) {
        for (int i = 0; i < nodes.length; i++) {
            final Node node = nodes[i];
            PauseTransition pause = new PauseTransition(Duration.millis(i * delayMillis));
            pause.setOnFinished(e -> slideInUp(node, 500));
            pause.play();
        }
    }

    // ========== HOVER EFFECT ==========
    public static void addHoverEffect(Node node) {
        node.setOnMouseEntered(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), node);
            scale.setToX(1.05);
            scale.setToY(1.05);
            scale.play();
        });

        node.setOnMouseExited(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), node);
            scale.setToX(1.0);
            scale.setToY(1.0);
            scale.play();
        });
    }

    // ========== CLICK EFFECT ==========
    public static void addClickEffect(Node node) {
        node.setOnMousePressed(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(100), node);
            scale.setToX(0.95);
            scale.setToY(0.95);
            scale.play();
        });

        node.setOnMouseReleased(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(100), node);
            scale.setToX(1.0);
            scale.setToY(1.0);
            scale.play();
        });
    }

    // ========== LOADING SPINNER ==========
    public static Timeline createLoadingAnimation(Node node) {
        RotateTransition rotate = new RotateTransition(Duration.millis(1000), node);
        rotate.setByAngle(360);
        rotate.setCycleCount(Timeline.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.play();
        return null;
    }

    // ========== ATTENTION SEEKER ==========
    public static void attentionSeeker(Node node) {
        ScaleTransition scale1 = new ScaleTransition(Duration.millis(200), node);
        scale1.setToX(1.1);
        scale1.setToY(1.1);

        ScaleTransition scale2 = new ScaleTransition(Duration.millis(200), node);
        scale2.setToX(1.0);
        scale2.setToY(1.0);

        SequentialTransition sequence = new SequentialTransition(scale1, scale2, scale1, scale2);
        sequence.play();
    }

    // ========== SLIDE AND FADE ==========
    public static void slideAndFade(Node node, double fromX, double toX, double fromY, double toY) {
        TranslateTransition translate = new TranslateTransition(Duration.millis(600), node);
        translate.setFromX(fromX);
        translate.setToX(toX);
        translate.setFromY(fromY);
        translate.setToY(toY);

        FadeTransition fade = new FadeTransition(Duration.millis(600), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);

        ParallelTransition parallel = new ParallelTransition(translate, fade);
        parallel.play();
    }
}
