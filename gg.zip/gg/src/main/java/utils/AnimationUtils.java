package utils;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.scene.effect.GaussianBlur;
import javafx.util.Duration;

/**
 * Utilidad para agregar animaciones profesionales a los componentes JavaFX
 * Sistema BookinnGo - Animaciones Modernas
 */
public class AnimationUtils {

    // ==================== FADE ANIMATIONS ====================
    
    /**
     * Animación de aparición gradual (Fade In)
     */
    public static void fadeIn(Node node, double duration) {
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();
    }

    /**
     * Animación de desaparición gradual (Fade Out)
     */
    public static void fadeOut(Node node, double duration) {
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        fade.play();
    }

    // ==================== SLIDE ANIMATIONS ====================
    
    /**
     * Animación deslizar desde la izquierda
     */
    public static void slideInLeft(Node node, double duration) {
        TranslateTransition slide = new TranslateTransition(Duration.millis(duration), node);
        slide.setFromX(-100);
        slide.setToX(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(slide, fade);
        parallel.play();
    }

    /**
     * Animación deslizar desde la derecha
     */
    public static void slideInRight(Node node, double duration) {
        TranslateTransition slide = new TranslateTransition(Duration.millis(duration), node);
        slide.setFromX(100);
        slide.setToX(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(slide, fade);
        parallel.play();
    }

    /**
     * Animación deslizar desde arriba
     */
    public static void slideInUp(Node node, double duration) {
        TranslateTransition slide = new TranslateTransition(Duration.millis(duration), node);
        slide.setFromY(50);
        slide.setToY(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(slide, fade);
        parallel.play();
    }

    /**
     * Animación deslizar desde abajo
     */
    public static void slideInDown(Node node, double duration) {
        TranslateTransition slide = new TranslateTransition(Duration.millis(duration), node);
        slide.setFromY(-50);
        slide.setToY(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(slide, fade);
        parallel.play();
    }

    // ==================== SCALE ANIMATIONS ====================
    
    /**
     * Animación de zoom in (agrandar)
     */
    public static void zoomIn(Node node, double duration) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(duration), node);
        scale.setFromX(0.8);
        scale.setFromY(0.8);
        scale.setToX(1.0);
        scale.setToY(1.0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(scale, fade);
        parallel.play();
    }

    /**
     * Animación de zoom out (achicar)
     */
    public static void zoomOut(Node node, double duration) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(duration), node);
        scale.setFromX(1.0);
        scale.setFromY(1.0);
        scale.setToX(0.8);
        scale.setToY(0.8);
        
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        
        ParallelTransition parallel = new ParallelTransition(scale, fade);
        parallel.play();
    }

    // ==================== BOUNCE ANIMATION ====================
    
    /**
     * Animación de rebote
     */
    public static void bounce(Node node) {
        ScaleTransition scale1 = new ScaleTransition(Duration.millis(100), node);
        scale1.setToX(1.1);
        scale1.setToY(1.1);
        
        ScaleTransition scale2 = new ScaleTransition(Duration.millis(100), node);
        scale2.setToX(1.0);
        scale2.setToY(1.0);
        
        SequentialTransition seq = new SequentialTransition(scale1, scale2);
        seq.play();
    }

    // ==================== SHAKE ANIMATION ====================
    
    /**
     * Animación de sacudida (para errores)
     */
    public static void shake(Node node) {
        TranslateTransition tt = new TranslateTransition(Duration.millis(50), node);
        tt.setFromX(0);
        tt.setByX(10);
        tt.setCycleCount(6);
        tt.setAutoReverse(true);
        tt.play();
    }

    // ==================== PULSE ANIMATION ====================
    
    /**
     * Animación de pulso (latido)
     */
    public static void pulse(Node node) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(500), node);
        scale.setToX(1.05);
        scale.setToY(1.05);
        scale.setCycleCount(Timeline.INDEFINITE);
        scale.setAutoReverse(true);
        scale.play();
    }

    /**
     * Detener animación de pulso
     */
    public static void stopPulse(Node node) {
        node.setScaleX(1.0);
        node.setScaleY(1.0);
    }

    // ==================== ROTATE ANIMATION ====================
    
    /**
     * Animación de rotación
     */
    public static void rotate(Node node, double angle, double duration) {
        RotateTransition rotate = new RotateTransition(Duration.millis(duration), node);
        rotate.setByAngle(angle);
        rotate.play();
    }

    /**
     * Animación de rotación continua
     */
    public static void rotateContinuous(Node node) {
        RotateTransition rotate = new RotateTransition(Duration.seconds(2), node);
        rotate.setByAngle(360);
        rotate.setCycleCount(Timeline.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.play();
    }

    // ==================== BLUR ANIMATION ====================
    
    /**
     * Animación de desenfoque
     */
    public static void blurIn(Node node, double duration) {
        GaussianBlur blur = new GaussianBlur(0);
        node.setEffect(blur);
        
        Timeline timeline = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(blur.radiusProperty(), 0)),
            new KeyFrame(Duration.millis(duration), new KeyValue(blur.radiusProperty(), 10))
        );
        timeline.play();
    }

    /**
     * Animación de enfoque
     */
    public static void blurOut(Node node, double duration) {
        GaussianBlur blur = new GaussianBlur(10);
        node.setEffect(blur);
        
        Timeline timeline = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(blur.radiusProperty(), 10)),
            new KeyFrame(Duration.millis(duration), new KeyValue(blur.radiusProperty(), 0))
        );
        timeline.play();
    }

    // ==================== SEQUENTIAL ANIMATIONS ====================
    
    /**
     * Animar múltiples nodos en secuencia
     */
    public static void animateSequence(Node[] nodes, double delayBetween) {
        SequentialTransition sequence = new SequentialTransition();
        
        for (Node node : nodes) {
            FadeTransition fade = new FadeTransition(Duration.millis(300), node);
            fade.setFromValue(0.0);
            fade.setToValue(1.0);
            
            TranslateTransition slide = new TranslateTransition(Duration.millis(300), node);
            slide.setFromY(30);
            slide.setToY(0);
            
            ParallelTransition parallel = new ParallelTransition(fade, slide);
            
            PauseTransition pause = new PauseTransition(Duration.millis(delayBetween));
            
            sequence.getChildren().addAll(parallel, pause);
        }
        
        sequence.play();
    }

    // ==================== HOVER EFFECTS ====================
    
    /**
     * Efecto hover para botones (elevar)
     */
    public static void applyHoverEffect(Node node) {
        node.setOnMouseEntered(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), node);
            scale.setToX(1.05);
            scale.setToY(1.05);
            scale.play();
        });
        
        node.setOnMouseExited(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), node);
            scale.setToX(1.0);
            scale.setToY(1.0);
            scale.play();
        });
    }

    /**
     * Efecto hover para tarjetas (elevar con sombra)
     */
    public static void applyCardHoverEffect(Node node) {
        node.setOnMouseEntered(e -> {
            TranslateTransition translate = new TranslateTransition(Duration.millis(200), node);
            translate.setToY(-5);
            translate.play();
        });
        
        node.setOnMouseExited(e -> {
            TranslateTransition translate = new TranslateTransition(Duration.millis(200), node);
            translate.setToY(0);
            translate.play();
        });
    }

    // ==================== LOADING ANIMATION ====================
    
    /**
     * Animación de carga (spinner)
     */
    public static RotateTransition createLoadingAnimation(Node node) {
        RotateTransition rotate = new RotateTransition(Duration.seconds(1), node);
        rotate.setByAngle(360);
        rotate.setCycleCount(Timeline.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        return rotate;
    }

    // ==================== SUCCESS/ERROR ANIMATIONS ====================
    
    /**
     * Animación de éxito (verde con escala)
     */
    public static void successAnimation(Node node) {
        // Cambiar a verde temporalmente
        String originalStyle = node.getStyle();
        node.setStyle(originalStyle + "-fx-background-color: #10b981;");
        
        // Animación de escala
        ScaleTransition scale = new ScaleTransition(Duration.millis(300), node);
        scale.setToX(1.1);
        scale.setToY(1.1);
        scale.setAutoReverse(true);
        scale.setCycleCount(2);
        scale.setOnFinished(e -> node.setStyle(originalStyle));
        scale.play();
    }

    /**
     * Animación de error (rojo con sacudida)
     */
    public static void errorAnimation(Node node) {
        // Cambiar a rojo temporalmente
        String originalStyle = node.getStyle();
        node.setStyle(originalStyle + "-fx-border-color: #ef4444; -fx-border-width: 2;");
        
        // Animación de sacudida
        shake(node);
        
        // Restaurar estilo después de 1 segundo
        PauseTransition pause = new PauseTransition(Duration.seconds(1));
        pause.setOnFinished(e -> node.setStyle(originalStyle));
        pause.play();
    }

    // ==================== PAGE TRANSITION ====================
    
    /**
     * Transición de página (fade + slide)
     */
    public static void pageTransition(Node oldPage, Node newPage, double duration) {
        // Fade out y slide left para página antigua
        if (oldPage != null) {
            FadeTransition fadeOut = new FadeTransition(Duration.millis(duration), oldPage);
            fadeOut.setToValue(0.0);
            
            TranslateTransition slideOut = new TranslateTransition(Duration.millis(duration), oldPage);
            slideOut.setToX(-50);
            
            ParallelTransition oldTransition = new ParallelTransition(fadeOut, slideOut);
            oldTransition.play();
        }
        
        // Fade in y slide right para página nueva
        if (newPage != null) {
            newPage.setOpacity(0.0);
            newPage.setTranslateX(50);
            
            FadeTransition fadeIn = new FadeTransition(Duration.millis(duration), newPage);
            fadeIn.setToValue(1.0);
            
            TranslateTransition slideIn = new TranslateTransition(Duration.millis(duration), newPage);
            slideIn.setToX(0);
            
            ParallelTransition newTransition = new ParallelTransition(fadeIn, slideIn);
            newTransition.setDelay(Duration.millis(duration / 2));
            newTransition.play();
        }
    }
}
