
package dao;

import model.Trabajador;
import java.sql.SQLException;


public interface ITrabajadorDao extends IBaseDao <Trabajador> {
    Trabajador findByUsuario(String usuario) throws SQLException;
    Trabajador authenticate(String usuario, String contrasena) throws SQLException;
}
