
package dao.impl;
import ConexionBase.Conexion;
import model.Cliente;
import dao.IClienteDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class ClienteDaoImpl implements IClienteDao{

        private final Conexion conexion;  // Dependencia inyectada para obtener conexiones

    // Constructor con inyección de dependencia
    public ClienteDaoImpl(Conexion conexion) {
        this.conexion = conexion;
    }

    @Override
    public void create(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO clientes (primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, " +
                     "tipo_documento, documento, estado, email, telefono, categoria) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // La conexión se obtiene y se cierra en cada operación
        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, cliente.getPrimerNombre());
            stmt.setString(2, cliente.getSegundoNombre());
            stmt.setString(3, cliente.getPrimerApellido());
            stmt.setString(4, cliente.getSegundoApellido());
            stmt.setString(5, cliente.getTipoDocumento());
            stmt.setString(6, cliente.getDocumento());
            stmt.setString(7, cliente.getEstado());
            stmt.setString(8, cliente.getEmail());
            stmt.setLong(9, cliente.getTelefono());
            stmt.setString(10, cliente.getCategoria());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    cliente.setIdCliente(rs.getLong(1));
                }
            }
        }
    }

    @Override
    public Cliente read(Long id) throws SQLException {
        String sql = "SELECT * FROM clientes WHERE id_cliente = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToCliente(rs);
                }
            }
        }
        return null;
    }

    @Override
    public void update(Cliente cliente) throws SQLException {
        String sql = "UPDATE clientes SET primer_nombre=?, segundo_nombre=?, primer_apellido=?, segundo_apellido=?, " +
                     "tipo_documento=?, documento=?, estado=?, email=?, telefono=?, categoria=? WHERE id_cliente=?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cliente.getPrimerNombre());
            stmt.setString(2, cliente.getSegundoNombre());
            stmt.setString(3, cliente.getPrimerApellido());
            stmt.setString(4, cliente.getSegundoApellido());
            stmt.setString(5, cliente.getTipoDocumento());
            stmt.setString(6, cliente.getDocumento());
            stmt.setString(7, cliente.getEstado());
            stmt.setString(8, cliente.getEmail());
            stmt.setLong(9, cliente.getTelefono());
            stmt.setString(10, cliente.getCategoria());
            stmt.setLong(11, cliente.getIdCliente());

            stmt.executeUpdate();
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        String sql = "DELETE FROM clientes WHERE id_cliente = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Cliente> findAll() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM clientes";

        try (Connection conn = conexion.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                clientes.add(mapResultSetToCliente(rs));
            }
        }
        return clientes;
    }

    @Override
    public Cliente findByDocumento(String documento) throws SQLException {
        String sql = "SELECT * FROM clientes WHERE documento = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, documento);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToCliente(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Cliente> findByEstado(String estado) throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM clientes WHERE estado = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, estado);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    clientes.add(mapResultSetToCliente(rs));
                }
            }
        }
        return clientes;
    }

    // Método privado de mapeo: responsabilidad interna del DAO
    private Cliente mapResultSetToCliente(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setIdCliente(rs.getLong("id_cliente"));
        cliente.setPrimerNombre(rs.getString("primer_nombre"));
        cliente.setSegundoNombre(rs.getString("segundo_nombre"));
        cliente.setPrimerApellido(rs.getString("primer_apellido"));
        cliente.setSegundoApellido(rs.getString("segundo_apellido"));
        cliente.setTipoDocumento(rs.getString("tipo_documento"));
        cliente.setDocumento(rs.getString("documento"));
        cliente.setEstado(rs.getString("estado"));
        cliente.setEmail(rs.getString("email"));
        cliente.setTelefono(rs.getLong("telefono"));
        cliente.setCategoria(rs.getString("categoria"));
        return cliente;
    }
}
    

