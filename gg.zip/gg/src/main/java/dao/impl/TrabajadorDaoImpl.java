
package dao.impl;

import ConexionBase.Conexion;
import model.Rol;
import model.Trabajador;
import dao.ITrabajadorDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class TrabajadorDaoImpl implements ITrabajadorDao {

    private final Conexion conexion;

    public TrabajadorDaoImpl(Conexion conexion) {
        this.conexion = conexion;
    }

    @Override
    public void create(Trabajador trabajador) throws SQLException {
        String sql = "INSERT INTO trabajadores (primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, " +
                     "tipo_documento, documento, estado, email, telefono, usuario, contrasena, sueldo, id_rol) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, trabajador.getPrimerNombre());
            stmt.setString(2, trabajador.getSegundoNombre());
            stmt.setString(3, trabajador.getPrimerApellido());
            stmt.setString(4, trabajador.getSegundoApellido());
            stmt.setString(5, trabajador.getTipoDocumento());
            stmt.setString(6, trabajador.getDocumento());
            stmt.setString(7, trabajador.getEstado());
            stmt.setString(8, trabajador.getEmail());
            stmt.setLong(9, trabajador.getTelefono());
            stmt.setString(10, trabajador.getUsuario());
            stmt.setString(11, trabajador.getContrasena());
            stmt.setDouble(12, trabajador.getSueldo());
            stmt.setLong(13, trabajador.getRol().getIdRol());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    trabajador.setIdTrabajador(rs.getLong(1));
                }
            }
        }
    }

    @Override
    public Trabajador read(Long id) throws SQLException {
        String sql = "SELECT t.*, r.id_rol, r.nombre_rol, r.descripcion " +
                     "FROM trabajadores t " +
                     "LEFT JOIN roles r ON t.id_rol = r.id_rol " +
                     "WHERE t.id_trabajador = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTrabajador(rs);
                }
            }
        }

        return null;
    }

    @Override
    public void update(Trabajador trabajador) throws SQLException {
        String sql = "UPDATE trabajadores SET primer_nombre = ?, segundo_nombre = ?, primer_apellido = ?, segundo_apellido = ?, " +
                     "tipo_documento = ?, documento = ?, estado = ?, email = ?, telefono = ?, usuario = ?, contrasena = ?, " +
                     "sueldo = ?, id_rol = ? " +
                     "WHERE id_trabajador = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, trabajador.getPrimerNombre());
            stmt.setString(2, trabajador.getSegundoNombre());
            stmt.setString(3, trabajador.getPrimerApellido());
            stmt.setString(4, trabajador.getSegundoApellido());
            stmt.setString(5, trabajador.getTipoDocumento());
            stmt.setString(6, trabajador.getDocumento());
            stmt.setString(7, trabajador.getEstado());
            stmt.setString(8, trabajador.getEmail());
            stmt.setLong(9, trabajador.getTelefono());
            stmt.setString(10, trabajador.getUsuario());
            stmt.setString(11, trabajador.getContrasena());
            stmt.setDouble(12, trabajador.getSueldo());
            stmt.setLong(13, trabajador.getRol().getIdRol());
            stmt.setLong(14, trabajador.getIdTrabajador());

            stmt.executeUpdate();
        }
    }

    @Override
    public void delete(Long id) throws SQLException {
        String sql = "DELETE FROM trabajadores WHERE id_trabajador = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Trabajador> findAll() throws SQLException {
        List<Trabajador> lista = new ArrayList<>();

        String sql = "SELECT t.*, r.id_rol, r.nombre_rol, r.descripcion " +
                     "FROM trabajadores t " +
                     "LEFT JOIN roles r ON t.id_rol = r.id_rol";

        try (Connection conn = conexion.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(mapResultSetToTrabajador(rs));
            }
        }

        return lista;
    }

    @Override
    public Trabajador findByUsuario(String usuario) throws SQLException {
        String sql = "SELECT t.*, r.id_rol, r.nombre_rol, r.descripcion " +
                     "FROM trabajadores t " +
                     "LEFT JOIN roles r ON t.id_rol = r.id_rol " +
                     "WHERE t.usuario = ?";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTrabajador(rs);
                }
            }
        }

        return null;
    }

    @Override
    public Trabajador authenticate(String usuario, String contrasena) throws SQLException {
        String sql = "SELECT t.*, r.id_rol, r.nombre_rol, r.descripcion " +
                     "FROM trabajadores t " +
                     "LEFT JOIN roles r ON t.id_rol = r.id_rol " +
                     "WHERE t.usuario = ? AND t.contrasena = ? AND t.estado = 'ACTIVO'";

        try (Connection conn = conexion.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario);
            stmt.setString(2, contrasena);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTrabajador(rs);
                }
            }
        }

        return null;
    }

    private Trabajador mapResultSetToTrabajador(ResultSet rs) throws SQLException {
        Trabajador t = new Trabajador();
        t.setIdTrabajador(rs.getLong("id_trabajador"));
        t.setPrimerNombre(rs.getString("primer_nombre"));
        t.setSegundoNombre(rs.getString("segundo_nombre"));
        t.setPrimerApellido(rs.getString("primer_apellido"));
        t.setSegundoApellido(rs.getString("segundo_apellido"));
        t.setTipoDocumento(rs.getString("tipo_documento"));
        t.setDocumento(rs.getString("documento"));
        t.setEstado(rs.getString("estado"));
        t.setEmail(rs.getString("email"));
        t.setTelefono(rs.getLong("telefono"));
        t.setUsuario(rs.getString("usuario"));
        t.setContrasena(rs.getString("contrasena"));
        t.setSueldo(rs.getDouble("sueldo"));

        Rol rol = new Rol();
        rol.setIdRol(rs.getLong("id_rol"));
        rol.setNombreRol(rs.getString("nombre_rol"));
        rol.setDescripcion(rs.getString("descripcion"));
        t.setRol(rol);

        return t;
    }
}