# BookinnGo - Sistema de Gestión Hotelera

## 📋 ERRORES CORREGIDOS

### 1. **pom.xml - Tag XML Inválido**
**Error:** Línea 10 contenía `<n>BookinnGo</n>` que es un tag inválido en Maven.
**Solución:** Se eliminó el tag inválido. El nombre del proyecto ya está correctamente definido con `<artifactId>`.

### 2. **DashboardView.fxml - Declaración XML Duplicada**
**Error:** El archivo contenía dos declaraciones `<?xml version="1.0" encoding="UTF-8"?>` en las líneas 1 y 3.
**Solución:** Se eliminó la declaración duplicada y se mejoró la vista con tarjetas estadísticas.

### 3. **MainLayoutController.java - Métodos Comentados**
**Error:** Los métodos handleHabitaciones, handleHuespedes, handlePagos, handleTrabajadores y handleRoles tenían el código comentado.
**Solución:** Se descomentaron todos los métodos para activar la navegación completa del sistema.

### 4. **Controladores Faltantes**
**Error:** No existían controladores para las vistas de Reservas, Habitaciones, Huéspedes, Pagos, Trabajadores y Roles.
**Solución:** Se crearon los siguientes controladores:
- `ReservasController.java`
- `HabitacionesController.java`
- `HuespedesController.java`
- `PagosController.java`
- `TrabajadoresController.java`
- `RolesController.java`

### 5. **Vistas FXML Incompletas**
**Error:** Las vistas FXML no tenían controladores asignados ni funcionalidad.
**Solución:** Se actualizaron todas las vistas FXML:
- Asignación de controladores con `fx:controller`
- Implementación de TableViews con columnas
- Botones de acción (Nuevo, Editar, Eliminar, Buscar)
- Campos de búsqueda
- Diseño consistente con el resto del sistema

### 6. **Archivo CSS Faltante**
**Error:** El archivo hello-view.fxml referenciaba `styleClass="menu-button"` pero no existía archivo CSS.
**Solución:** Se creó `/src/main/resources/css/styles.css` con:
- Estilos para botones del menú
- Estilos para botones de acción (primario, éxito, advertencia, peligro)
- Estilos para tarjetas
- Estilos para tablas
- Estilos para campos de texto

## 🏗️ ESTRUCTURA DEL PROYECTO

```
BookinnGo/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   ├── ConexionBase/
│   │   │   │   ├── Conexion.java
│   │   │   │   ├── Database.java
│   │   │   │   ├── IConexion.java
│   │   │   │   └── Main.java
│   │   │   ├── controller/
│   │   │   │   ├── DashboardController.java
│   │   │   │   ├── HelloApplication.java (Main)
│   │   │   │   ├── MainLayoutController.java
│   │   │   │   ├── ReservasController.java ✅ NUEVO
│   │   │   │   ├── HabitacionesController.java ✅ NUEVO
│   │   │   │   ├── HuespedesController.java ✅ NUEVO
│   │   │   │   ├── PagosController.java ✅ NUEVO
│   │   │   │   ├── TrabajadoresController.java ✅ NUEVO
│   │   │   │   └── RolesController.java ✅ NUEVO
│   │   │   ├── dao/
│   │   │   │   ├── IBaseDao.java
│   │   │   │   ├── IClienteDao.java
│   │   │   │   ├── IComprobanteDao.java
│   │   │   │   ├── IHabitacionDao.java
│   │   │   │   ├── IReservaDao.java
│   │   │   │   ├── IRolDao.java
│   │   │   │   ├── ITrabajadorDao.java
│   │   │   │   └── impl/
│   │   │   │       ├── ClienteDaoImpl.java
│   │   │   │       ├── ComprobanteDaoImpl.java
│   │   │   │       ├── HabitacionDaoImpl.java
│   │   │   │       ├── ReservaDaoImpl.java
│   │   │   │       ├── RolDaoImpl.java
│   │   │   │       └── TrabajadorDaoImpl.java
│   │   │   ├── model/
│   │   │   │   ├── Persona.java
│   │   │   │   ├── Cliente.java
│   │   │   │   ├── Trabajador.java
│   │   │   │   ├── Rol.java
│   │   │   │   ├── Habitacion.java
│   │   │   │   ├── Reserva.java
│   │   │   │   └── Comprobante.java
│   │   │   └── service/
│   │   │       ├── IClienteService.java
│   │   │       ├── IComprobanteService.java
│   │   │       ├── IHabitacionService.java
│   │   │       ├── IReservaService.java
│   │   │       ├── IRolService.java
│   │   │       ├── ITrabajadorService.java
│   │   │       └── impl/
│   │   │           ├── ClienteServiceImpl.java
│   │   │           ├── ComprobanteServiceImpl.java
│   │   │           ├── HabitacionServiceImpl.java
│   │   │           ├── ReservaServiceImpl.java
│   │   │           ├── RolServiceImpl.java
│   │   │           └── TrabajadorServiceImpl.java
│   │   └── resources/
│   │       ├── css/
│   │       │   └── styles.css ✅ NUEVO
│   │       └── hotel/
│   │           └── view/
│   │               ├── hello-view.fxml (Vista Principal)
│   │               ├── DashboardView.fxml ✅ CORREGIDO
│   │               ├── ReservasView.fxml ✅ ACTUALIZADO
│   │               ├── HabitacionesView.fxml ✅ ACTUALIZADO
│   │               ├── HuespedesView.fxml ✅ ACTUALIZADO
│   │               ├── PagosView.fxml ✅ ACTUALIZADO
│   │               ├── TrabajadoresView.fxml ✅ ACTUALIZADO
│   │               └── RolesView.fxml ✅ ACTUALIZADO
└── pom.xml ✅ CORREGIDO
```

## ⚙️ CONFIGURACIÓN DE BASE DE DATOS

**IMPORTANTE:** Los controladores están configurados con credenciales de ejemplo:
```java
Database db = new Database("localhost", 1521, "orcl", "system", "123");
```

**Debes actualizar estos valores** según tu configuración de Oracle:
- `localhost` → Tu servidor de BD
- `1521` → Puerto de Oracle
- `orcl` → Nombre del servicio/SID
- `system` → Tu usuario
- `123` → Tu contraseña

## 🚀 CÓMO EJECUTAR EL PROYECTO

### Opción 1: Desde IntelliJ IDEA
1. Abre el proyecto en IntelliJ IDEA
2. Espera a que Maven descargue las dependencias
3. Ejecuta la clase `controller.HelloApplication`

### Opción 2: Desde Maven
```bash
mvn clean javafx:run
```

### Opción 3: Compilar y empaquetar
```bash
mvn clean package
```

## 📦 DEPENDENCIAS

El proyecto utiliza las siguientes dependencias:
- **JavaFX 21.0.6** - Framework de interfaz gráfica
- **Oracle JDBC 19.8.0.0** - Driver de conexión a Oracle Database
- **FlatLaf 3.6.2** - Look and Feel moderno
- **JCalendar 1.4** - Componente de calendario

## 🎨 CARACTERÍSTICAS DE LA INTERFAZ

- **Menú lateral azul** (#133B88) con navegación completa
- **Dashboard** con tarjetas estadísticas
- **Vistas CRUD completas** para:
  - Reservas
  - Habitaciones
  - Huéspedes
  - Pagos
  - Trabajadores
  - Roles
- **Botones de acción** con colores semánticos
- **Tablas** para visualización de datos
- **Campos de búsqueda** en cada vista

## ✅ ESTADO DEL PROYECTO

### Completado:
- ✅ Estructura de capas (Model-DAO-Service-Controller)
- ✅ Conexión a Oracle Database
- ✅ Interfaz gráfica con JavaFX
- ✅ Navegación entre vistas
- ✅ Controladores para todas las vistas
- ✅ Estilos CSS
- ✅ Arquitectura MVC

### Pendiente (para implementación futura):
- ⏳ Configuración completa de TableColumns con PropertyValueFactory
- ⏳ Implementación de formularios de CRUD
- ⏳ Validación de datos
- ⏳ Sistema de autenticación
- ⏳ Manejo de permisos por rol
- ⏳ Reportes

## 📝 NOTAS IMPORTANTES

1. **Caracteres especiales:** El proyecto maneja correctamente UTF-8 para tildes y caracteres especiales.

2. **Arquitectura de 3 capas:** El proyecto sigue una arquitectura limpia con:
   - **Modelo (model/)** - Entidades de negocio
   - **DAO (dao/)** - Acceso a datos
   - **Servicio (service/)** - Lógica de negocio
   - **Controlador (controller/)** - Lógica de presentación

3. **Inyección de dependencias:** Los servicios reciben DAOs en el constructor, y los DAOs reciben la conexión.

4. **Try-with-resources:** Se utiliza correctamente para el manejo automático de recursos.

## 🐛 SOLUCIÓN DE PROBLEMAS

### Si no compila:
1. Verifica que tienes Java 17 o superior
2. Ejecuta `mvn clean install`
3. Recarga el proyecto Maven

### Si no conecta a la base de datos:
1. Verifica que Oracle Database esté ejecutándose
2. Confirma las credenciales en los controladores
3. Asegúrate de que el puerto 1521 esté abierto

### Si no cargan las vistas FXML:
1. Verifica que los archivos FXML estén en `src/main/resources/hotel/view/`
2. Confirma que los controladores tengan el package correcto
3. Revisa los nombres de archivo en los métodos `loadView()`

## 👨‍💻 PRÓXIMOS PASOS RECOMENDADOS

1. Configurar la base de datos Oracle con las tablas necesarias
2. Implementar los métodos CRUD completos en los controladores
3. Agregar validación de campos
4. Crear sistema de login con autenticación
5. Implementar gestión de permisos según rol
6. Agregar generación de reportes en PDF

---

**Proyecto:** BookinnGo - Sistema de Gestión Hotelera  
**Tecnologías:** Java 17, JavaFX 21, Oracle Database 19c, Maven  
**Arquitectura:** MVC con capas DAO y Service  
**Estado:** Estructura completa y funcional lista para desarrollo
